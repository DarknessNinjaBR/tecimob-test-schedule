



<?php $__env->startSection('title', "Agendeyson - Edição"); ?>
    
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col col-sm-3">
        <form action="<?php echo e(route('contact.update', ['contact'=>$contact->id])); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Nome</label>
            <input type="text" name="name" value="<?php echo e($contact->name); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
            <?php if($errors->has('name')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Numero de telefone</label>
            <input type="text" name="phone" class="form-control" aria-describedby="emailHelp" value="<?php echo e($contact->phone); ?>" maxlength="15" id="phone_with_ddd">
            <?php if($errors->has('phone')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
                <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3" maxlength="250"><?php echo e($contact->description); ?></textarea>
                <?php if($errors->has('description')): ?>
                <div class="alert alert-danger" role="alert">
                    <strong><?php echo e($errors->first('description')); ?></strong>
                </div>
            <?php endif; ?>
              </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            
        </form>
    </div>
</div>
    
<script src="<?php echo e(asset('/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/jquery.mask.js')); ?>"></script>
<script>
    $(document).ready(function(){
            $('#date').mask('11/11/1111');
            $('time').mask('00:00:00');
            $('date_time').mask('99/99/9999 00:00:00');
            $('#cep').mask('99999-999');
            $('#phone').mask('9999-9999');
            $('#phone_with_ddd').mask('(99) 99999-9999');
            $('#phone_us').mask('(999) 999-9999');
            $('mixed').mask('AAA 000-S0S');
            $('#money').mask('000.000.000.000.000,00', {reverse: true});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos\Entrevistas\DezSistemas\agenda\resources\views/edit.blade.php ENDPATH**/ ?>