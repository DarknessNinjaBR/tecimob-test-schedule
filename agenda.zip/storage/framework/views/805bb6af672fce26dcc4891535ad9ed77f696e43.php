



<?php $__env->startSection('title', "Agendeyson - Home"); ?>
    
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col col-sm-3">
        <form action="<?php echo e(route('contact.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Nome</label>
            <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e(old('name')); ?>">
            <?php if($errors->has('name')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Numero de telefone</label>
            <input type="text" name="phone" class="form-control" aria-describedby="emailHelp" value="<?php echo e(old('phone')); ?>" maxlength="15" id="phone_with_ddd">
            <?php if($errors->has('phone')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
                <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3" maxlength="250"><?php echo e(old('description')); ?></textarea>
              </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            
        </form>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col col-6">
        <table class="table table-striped">
            <div class="row justify-content-center">
            <div class="col col-sm-3">
                <form method="GET" action="<?php echo e(route('home')); ?>">
                    <label for="exampleInputEmail1" class="form-label">Pesquisar</label>
                    <input type="text" class="form-control" name="search">
                    <br/>
                    <input type="submit" class="btn btn-primary" value="enviar"> - <a href="<?php echo e(route('home')); ?>">Limpar</a>
                </form>
            </div>
            </div>
            <thead>
                <br/>
                <tr>
                  <th scope="col">
                      <?php if($order == "asc"): ?>
                        <a href="<?php echo e(url('?order=desc')); ?>" style="text-decoration: none; color: #212529;">
                            ▼ Nome
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(url('?order=asc')); ?>" style="text-decoration: none; color: #212529;">
                            ▲ Nome
                        </a>
                        <?php endif; ?>
                    </th>
                  <th scope="col">Telefone</th>
                  <th scope="col">Descrição</th>
                  <th scope="col">Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contact->name); ?></td>
                    <td><?php echo e($contact->phone); ?></td>
                    <td><?php echo e($contact->description); ?></td>       
                    <td>
                        <a href="<?php echo e(route('contact.edit', ['contact' => $contact->id])); ?>" class="btn btn-sm btn-primary">✏️</a>
                        <form class="d-inline" action="<?php echo e(route('contact.destroy', ['contact' => $contact->id])); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button onclick="return confirm('Deseja mesmo excluir?');" class="btn btn-sm btn-danger">🗑️</button>
                        </form>
                        <a href="https://api.whatsapp.com/send?phone=55<?php echo e($contact->phone); ?>" target="_blank"><img class="btn btn-success" width="43" src="https://imagepng.org/wp-content/uploads/2017/08/WhatsApp-icone.png" alt="Whatsapp"></a>
                    </td>   
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
    </div>
</div>
    
<script src="<?php echo e(asset('/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/jquery.mask.js')); ?>"></script>
<script>
    $(document).ready(function(){
            $('#date').mask('11/11/1111');
            $('time').mask('00:00:00');
            $('date_time').mask('99/99/9999 00:00:00');
            $('#cep').mask('99999-999');
            $('#phone').mask('9999-9999');
            $('#phone_with_ddd').mask('(99) 99999-9999');
            $('#phone_us').mask('(999) 999-9999');
            $('mixed').mask('AAA 000-S0S');
            $('#money').mask('000.000.000.000.000,00', {reverse: true});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos\Entrevistas\DezSistemas\agenda\resources\views/home.blade.php ENDPATH**/ ?>