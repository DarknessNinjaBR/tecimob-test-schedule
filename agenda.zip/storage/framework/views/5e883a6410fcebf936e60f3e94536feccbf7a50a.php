

<?php $__env->startSection('title', "Agendeyson - Login"); ?>
    
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col col-sm-3">
            <form action="<?php echo e(route('login.auth')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </div>
                <?php endif; ?>
                </div>
                <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1">
                <?php if($errors->has('password')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </div>
                <?php endif; ?>
                </div>
                <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Lembrar senha</label>
                </div>
                <div class="mb-3">
                <p class="my-0">
                    <a href="<?php echo e(route('register')); ?>">
                        Não tem conta?<br/> Registre aqui!
                    </a>
                </p>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                
            </form>
        </div>
    <div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos\Entrevistas\DezSistemas\agenda\resources\views/login.blade.php ENDPATH**/ ?>